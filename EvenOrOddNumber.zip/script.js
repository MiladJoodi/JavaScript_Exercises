
var userNumber = prompt("Enter Your Numbet", 0);
if (userNumber % 2 == 0) {
    alert("Your Number Is 'Even'")
} else {
    alert("Your Number Is 'Odd'")
}